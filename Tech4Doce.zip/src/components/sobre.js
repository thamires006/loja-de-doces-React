
function Sobre() {

    return <div>
        <div className="divmiafoto">
            <img className="miafoto" alt="Thamiress" src="https://scontent-gig4-1.xx.fbcdn.net/v/t39.30808-6/323285036_544372657731182_2482026507500668216_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=174925&_nc_eui2=AeHB9ZaMrxMavFRvv4gJXHTn6IiCuHhReRPoiIK4eFF5EwFmbSTC1kNZp6W50eQBWkFDVTyTsCyRSLyFSUSF1-QH&_nc_ohc=PEHQmpjd30wAX_k3jW3&_nc_ht=scontent-gig4-1.xx&oh=00_AfCNyddvGA2EZNLqQB5YlyPcS_jUxiG0bRqhdUK2al-MlQ&oe=64D7F568"></img>

        </div>
        <p className="trajetoria">Faço parte de um projeto que é de grande importância tanto para a minha trajetória como para a de muitos outros. Entrei no curso da Tech4Me por meio do Projeto Galileo, projeto o qual permite que profissionais apadrinhem jovens e financiem o curso para o mesmo. Tive o prazer de ser apadrinhada por um profissional e foi algo que com toda a certeza mudou minha direção. Aprendi tecnologias que nunca sequer passaram pela minha mente, e sou muito feliz por isso.</p>

    </div>
}

export default Sobre